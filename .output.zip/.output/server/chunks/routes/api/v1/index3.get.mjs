import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { q as query } from '../../../_/db.mjs';
import { r as requireAdmin } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const index_get = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const res = await query(`
    SELECT 
      u.id,
      u.name,
      u.email,
      u.created_at,
      COALESCE(COUNT(o.id), 0) AS order_count,
      COALESCE(SUM(o.total_price), 0) AS total_spend
    FROM users u
    LEFT JOIN orders o ON LOWER(u.email) = LOWER(o.email)
    GROUP BY u.id, u.name, u.email, u.created_at
    ORDER BY u.created_at DESC
  `);
  return res.rows.map((row) => ({
    id: row.id,
    name: row.name,
    email: row.email,
    joinDate: new Date(row.created_at).toISOString().split("T")[0],
    orderCount: parseInt(row.order_count, 10) || 0,
    totalSpend: Math.round(parseFloat(row.total_spend || "0") * 100) / 100
  }));
});

export { index_get as default };
//# sourceMappingURL=index3.get.mjs.map
