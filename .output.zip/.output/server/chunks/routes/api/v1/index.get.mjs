import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { q as query } from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const index_get = defineEventHandler(async () => {
  const res = await query("SELECT * FROM categories ORDER BY name ASC");
  return res.rows;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
