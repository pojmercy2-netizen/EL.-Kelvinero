import { c as defineEventHandler, f as getRouterParam, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { q as query, g as getConnection } from '../../../../_/db.mjs';
import { r as requireAdmin } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const idStr = getRouterParam(event, "id");
  const id = idStr ? parseInt(idStr, 10) : NaN;
  if (isNaN(id)) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Invalid product ID" });
  }
  const body = await readBody(event);
  let { name, slug, description, price, category, category_id, collection, collection_id, image, stock, size, color } = body || {};
  if (!category_id && category) {
    const catName = String(category).trim().toUpperCase();
    const catSlug = catName.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    let catRes = await query("SELECT id FROM categories WHERE LOWER(name) = LOWER(?) OR slug = ?", [catName, catSlug]);
    if (catRes.rows.length === 0) {
      const conn = await getConnection();
      try {
        const [r] = await conn.execute("INSERT INTO categories (name, slug) VALUES (?, ?)", [catName, catSlug]);
        category_id = r.insertId;
      } finally {
        conn.release();
      }
    } else {
      category_id = catRes.rows[0].id;
    }
  }
  if (price !== void 0 && price < 0) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Price cannot be negative" });
  }
  if (stock !== void 0 && stock < 0) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Stock cannot be negative" });
  }
  const checkRes = await query("SELECT * FROM products WHERE id = ?", [id]);
  if (checkRes.rows.length === 0) {
    throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Product not found" });
  }
  if (category_id) {
    const catRes = await query("SELECT id FROM categories WHERE id = ?", [category_id]);
    if (catRes.rows.length === 0) {
      throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Category not found" });
    }
  }
  if (collection_id) {
    const collRes = await query("SELECT id FROM collections WHERE id = ?", [collection_id]);
    if (collRes.rows.length === 0) {
      throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Collection not found" });
    }
  }
  const updates = [];
  const params = [];
  if (name !== void 0) {
    updates.push("name = ?");
    params.push(name);
  }
  if (slug !== void 0) {
    const slugRes = await query("SELECT id FROM products WHERE slug = ? AND id != ?", [slug, id]);
    if (slugRes.rows.length > 0) {
      throw createError({ statusCode: 400, statusMessage: "Bad Request", message: `Slug '${slug}' already exists` });
    }
    updates.push("slug = ?");
    params.push(slug);
  }
  if (description !== void 0) {
    updates.push("description = ?");
    params.push(description);
  }
  if (price !== void 0) {
    updates.push("price = ?");
    params.push(price);
  }
  if (category_id !== void 0) {
    updates.push("category_id = ?");
    params.push(category_id || null);
  }
  if (collection_id !== void 0) {
    updates.push("collection_id = ?");
    params.push(collection_id || null);
  }
  if (image !== void 0) {
    updates.push("image = ?");
    params.push(image);
  }
  if (stock !== void 0) {
    updates.push("stock = ?");
    params.push(stock);
  }
  if (size !== void 0) {
    updates.push("size = ?");
    params.push(size ? JSON.stringify(size) : null);
  }
  if (color !== void 0) {
    updates.push("color = ?");
    params.push(color ? JSON.stringify(color) : null);
  }
  if (updates.length > 0) {
    params.push(id);
    await query(`UPDATE products SET ${updates.join(", ")} WHERE id = ?`, params);
  }
  const updatedRes = await query(`
    SELECT 
      p.*,
      cat.name AS cat_name, cat.slug AS cat_slug, cat.description AS cat_description, cat.created_at AS cat_created_at,
      coll.name AS coll_name, coll.slug AS coll_slug, coll.description AS coll_description, coll.created_at AS coll_created_at
    FROM products p
    LEFT JOIN categories cat ON p.category_id = cat.id
    LEFT JOIN collections coll ON p.collection_id = coll.id
    WHERE p.id = ?
  `, [id]);
  const p = updatedRes.rows[0];
  let sizeParsed = null, colorParsed = null;
  try {
    sizeParsed = p.size ? JSON.parse(p.size) : null;
  } catch {
    sizeParsed = p.size;
  }
  try {
    colorParsed = p.color ? JSON.parse(p.color) : null;
  } catch {
    colorParsed = p.color;
  }
  return {
    ...p,
    price: parseFloat(p.price),
    size: sizeParsed,
    color: colorParsed,
    category: p.category_id ? { id: p.category_id, name: p.cat_name, slug: p.cat_slug, description: p.cat_description, created_at: p.cat_created_at } : null,
    collection: p.collection_id ? { id: p.collection_id, name: p.coll_name, slug: p.coll_slug, description: p.coll_description, created_at: p.coll_created_at } : null
  };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
