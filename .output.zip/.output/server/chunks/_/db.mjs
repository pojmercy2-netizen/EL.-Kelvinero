import mysql from 'mysql2/promise';

let _pool = null;
function getMysqlPool() {
  if (_pool) return _pool;
  const connectionString = process.env.DATABASE_URL || (process.env.MYSQL_HOST ? void 0 : void 0);
  if (connectionString && connectionString.startsWith("mysql")) {
    _pool = mysql.createPool(connectionString);
  } else {
    _pool = mysql.createPool({
      host: process.env.MYSQL_HOST || "localhost",
      port: parseInt(process.env.MYSQL_PORT || "3306", 10),
      user: process.env.MYSQL_USER || "root",
      password: process.env.MYSQL_PASSWORD || "",
      database: process.env.MYSQL_DATABASE || "elkelvinero",
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      timezone: "+00:00"
    });
  }
  return _pool;
}
async function query(text, params) {
  const pool = getMysqlPool();
  const mysqlSql = text.replace(/\$\d+/g, "?");
  const [rows] = await pool.execute(mysqlSql, params || []);
  return { rows: Array.isArray(rows) ? rows : [rows] };
}
async function getConnection() {
  return getMysqlPool().getConnection();
}

export { getConnection as g, query as q };
//# sourceMappingURL=db.mjs.map
