import { c as defineEventHandler, f as getRouterParam, e as createError, h as setResponseStatus } from '../../../../_/nitro.mjs';
import { q as query } from '../../../../_/db.mjs';
import { r as requireAdmin } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__delete = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const idStr = getRouterParam(event, "id");
  const id = idStr ? parseInt(idStr, 10) : NaN;
  if (isNaN(id)) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Invalid order ID" });
  }
  const res = await query("SELECT id FROM orders WHERE id = ?", [id]);
  if (res.rows.length === 0) {
    throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Order not found" });
  }
  await query("DELETE FROM orders WHERE id = ?", [id]);
  setResponseStatus(event, 204);
  return null;
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
