import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { q as query, g as getConnection } from '../../../_/db.mjs';
import { r as requireAdmin } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const body = await readBody(event);
  const { name, slug, description } = body || {};
  if (!name || !slug) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Name and slug are required" });
  }
  const existingRes = await query("SELECT id FROM collections WHERE slug = ?", [slug]);
  if (existingRes.rows.length > 0) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: `A collection with slug '${slug}' already exists` });
  }
  const conn = await getConnection();
  try {
    const [result] = await conn.execute(
      "INSERT INTO collections (name, slug, description) VALUES (?, ?, ?)",
      [name, slug, description || null]
    );
    const newId = result.insertId;
    const newRes = await query("SELECT * FROM collections WHERE id = ?", [newId]);
    return newRes.rows[0];
  } finally {
    conn.release();
  }
});

export { index_post as default };
//# sourceMappingURL=index2.post.mjs.map
