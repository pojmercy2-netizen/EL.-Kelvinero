import { c as defineEventHandler } from '../../../_/nitro.mjs';
import { q as query } from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const index_get = defineEventHandler(async () => {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS settings (
        \`key\` VARCHAR(255) NOT NULL PRIMARY KEY,
        value TEXT NOT NULL
      )
    `);
    const res = await query("SELECT * FROM settings");
    const settingsObj = {
      storeName: "EL. KELVINERO",
      tagline: "Timeless Style. Made to Stand Out.",
      supportEmail: "concierge@elkelvinero.com",
      telephone: "+234 (0) 800 KELVINERO",
      whatsappNumber: "",
      businessHours: "Mon \u2013 Fri, 9am \u2013 6pm",
      contactAddress: "Lagos, Nigeria",
      responseTime: "Response within 24 hours",
      freeShippingThreshold: 5e4,
      standardShippingFee: 3500,
      currency: "NGN",
      autoApproveOrders: false,
      announcementEnabled: true,
      announcementText: "FREE SHIPPING ON ORDERS OVER \u20A650,000",
      announcementBg: "#1a1a1a",
      passcode: "elkelvinero2025",
      bankAccounts: [
        {
          id: "1",
          bankName: "Guaranty Trust Bank (GTBank)",
          accountNumber: "0123456789",
          accountName: "EL. KELVINERO NIGERIA LTD",
          instructions: "Please use your Order ID as the transfer description/reference."
        }
      ]
    };
    for (const row of res.rows) {
      try {
        settingsObj[row.key] = JSON.parse(row.value);
      } catch {
        settingsObj[row.key] = row.value;
      }
    }
    return settingsObj;
  } catch (err) {
    console.error("Error fetching settings:", err);
    return {
      storeName: "EL. KELVINERO",
      tagline: "Timeless Style. Made to Stand Out.",
      supportEmail: "concierge@elkelvinero.com",
      telephone: "+234 (0) 800 KELVINERO",
      freeShippingThreshold: 5e4,
      standardShippingFee: 3500,
      currency: "NGN",
      autoApproveOrders: false,
      announcementEnabled: true,
      announcementText: "FREE SHIPPING ON ORDERS OVER \u20A650,000",
      announcementBg: "#1a1a1a",
      passcode: "elkelvinero2025"
    };
  }
});

export { index_get as default };
//# sourceMappingURL=index7.get.mjs.map
