import { c as defineEventHandler, f as getRouterParam, e as createError, r as readBody } from '../../../../../_/nitro.mjs';
import { q as query } from '../../../../../_/db.mjs';
import { r as requireAdmin } from '../../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const status_put = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const idStr = getRouterParam(event, "id");
  const id = idStr ? parseInt(idStr, 10) : NaN;
  if (isNaN(id)) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Invalid order ID" });
  }
  const body = await readBody(event);
  const { status, payment_status } = body || {};
  const allowedStatuses = /* @__PURE__ */ new Set(["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]);
  const allowedPaymentStatuses = /* @__PURE__ */ new Set(["Unpaid", "Paid", "Failed", "Pending Verification"]);
  const checkRes = await query("SELECT id, status, payment_status FROM orders WHERE id = ?", [id]);
  if (checkRes.rows.length === 0) {
    throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Order not found" });
  }
  const currentOrder = checkRes.rows[0];
  let newStatus = currentOrder.status;
  let newPaymentStatus = currentOrder.payment_status;
  if (status && allowedStatuses.has(status)) {
    newStatus = status;
    if (status === "Processing" && newPaymentStatus !== "Paid") {
      newPaymentStatus = "Paid";
    }
  }
  if (payment_status && allowedPaymentStatuses.has(payment_status)) {
    newPaymentStatus = payment_status;
    if (payment_status === "Paid" && newStatus === "Pending") {
      newStatus = "Processing";
    }
  }
  await query("UPDATE orders SET status = ?, payment_status = ? WHERE id = ?", [newStatus, newPaymentStatus, id]);
  const updatedOrderRes = await query("SELECT * FROM orders WHERE id = ?", [id]);
  const updatedOrder = updatedOrderRes.rows[0];
  const itemsRes = await query(`
    SELECT oi.*, p.name, p.slug, p.image, p.price
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
  `, [id]);
  return {
    ...updatedOrder,
    total_price: parseFloat(updatedOrder.total_price),
    items: itemsRes.rows.map((item) => ({
      id: item.id,
      order_id: item.order_id,
      product_id: item.product_id,
      quantity: item.quantity,
      unit_price: parseFloat(item.unit_price),
      product: {
        id: item.product_id,
        name: item.name,
        slug: item.slug,
        image: item.image,
        price: parseFloat(item.price)
      }
    }))
  };
});

export { status_put as default };
//# sourceMappingURL=status.put.mjs.map
