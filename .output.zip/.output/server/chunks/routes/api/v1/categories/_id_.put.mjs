import { c as defineEventHandler, f as getRouterParam, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { q as query } from '../../../../_/db.mjs';
import { r as requireAdmin } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const _id__put = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const idStr = getRouterParam(event, "id");
  const id = idStr ? parseInt(idStr, 10) : NaN;
  if (isNaN(id)) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Invalid category ID" });
  }
  const body = await readBody(event);
  const { name, slug, description } = body || {};
  const checkRes = await query("SELECT * FROM categories WHERE id = ?", [id]);
  if (checkRes.rows.length === 0) {
    throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Category not found" });
  }
  const updates = [];
  const params = [];
  if (name !== void 0) {
    updates.push("name = ?");
    params.push(name);
  }
  if (slug !== void 0) {
    const slugRes = await query("SELECT id FROM categories WHERE slug = ? AND id != ?", [slug, id]);
    if (slugRes.rows.length > 0) {
      throw createError({ statusCode: 400, statusMessage: "Bad Request", message: `A category with slug '${slug}' already exists` });
    }
    updates.push("slug = ?");
    params.push(slug);
  }
  if (description !== void 0) {
    updates.push("description = ?");
    params.push(description);
  }
  if (updates.length > 0) {
    params.push(id);
    await query(`UPDATE categories SET ${updates.join(", ")} WHERE id = ?`, params);
  }
  const updatedRes = await query("SELECT * FROM categories WHERE id = ?", [id]);
  return updatedRes.rows[0];
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
