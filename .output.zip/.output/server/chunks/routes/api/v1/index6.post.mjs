import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { q as query } from '../../../_/db.mjs';
import { r as requireAdmin } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const index_post = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const body = await readBody(event);
  if (!body || typeof body !== "object") {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Invalid settings payload" });
  }
  await query(`
    CREATE TABLE IF NOT EXISTS settings (
      \`key\` VARCHAR(255) NOT NULL PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);
  for (const [key, value] of Object.entries(body)) {
    const jsonVal = JSON.stringify(value);
    await query(
      "INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)",
      [key, jsonVal]
    );
  }
  return { success: true, message: "Settings saved successfully" };
});

export { index_post as default };
//# sourceMappingURL=index6.post.mjs.map
