import { c as defineEventHandler, f as getRouterParam, e as createError } from '../../../../_/nitro.mjs';
import { q as query } from '../../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const _id__get = defineEventHandler(async (event) => {
  const idStr = getRouterParam(event, "id");
  const id = idStr ? parseInt(idStr, 10) : NaN;
  if (isNaN(id)) {
    throw createError({ statusCode: 400, statusMessage: "Bad Request", message: "Invalid order ID" });
  }
  const res = await query("SELECT * FROM orders WHERE id = ?", [id]);
  const order = res.rows[0];
  if (!order) {
    throw createError({ statusCode: 404, statusMessage: "Not Found", message: "Order not found" });
  }
  const itemsRes = await query(`
    SELECT oi.*, p.name, p.slug, p.image, p.price
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
  `, [id]);
  return {
    ...order,
    total_price: parseFloat(order.total_price),
    items: itemsRes.rows.map((item) => ({
      id: item.id,
      order_id: item.order_id,
      product_id: item.product_id,
      quantity: item.quantity,
      unit_price: parseFloat(item.unit_price),
      product: {
        id: item.product_id,
        name: item.name,
        slug: item.slug,
        image: item.image,
        price: parseFloat(item.price)
      }
    }))
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
