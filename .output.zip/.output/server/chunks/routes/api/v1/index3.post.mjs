import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { q as query, g as getConnection } from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { title, lookNumber, description, image, link } = body || {};
    if (!title || !image) {
      throw createError({
        statusCode: 400,
        statusMessage: "Title and Image URL are required"
      });
    }
    await query(`
      CREATE TABLE IF NOT EXISTS lookbook (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        look_number VARCHAR(50),
        description TEXT,
        image TEXT NOT NULL,
        link VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    const conn = await getConnection();
    try {
      const [result] = await conn.execute(
        "INSERT INTO lookbook (title, look_number, description, image, link) VALUES (?, ?, ?, ?, ?)",
        [title, lookNumber || "LOOK", description || "", image, link || "/shop"]
      );
      const newId = result.insertId;
      const rowRes = await query("SELECT * FROM lookbook WHERE id = ?", [newId]);
      const row = rowRes.rows[0];
      return {
        success: true,
        look: {
          id: row.id,
          title: row.title,
          lookNumber: row.look_number,
          description: row.description,
          image: row.image,
          link: row.link,
          createdAt: row.created_at
        }
      };
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error("Error creating lookbook entry:", err);
    throw createError({
      statusCode: err.statusCode || 500,
      statusMessage: err.statusMessage || "Failed to add lookbook entry"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index3.post.mjs.map
