import { c as defineEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_get = defineEventHandler(() => {
  return {
    status: "online",
    message: "EL. Kelvinero API is running \u{1F5A4}",
    docs: "/docs",
    version: "1.0.0"
  };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
