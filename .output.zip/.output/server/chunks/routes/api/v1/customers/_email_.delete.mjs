import { c as defineEventHandler, f as getRouterParam, e as createError, h as setResponseStatus } from '../../../../_/nitro.mjs';
import { q as query } from '../../../../_/db.mjs';
import { r as requireAdmin } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const _email__delete = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const email = getRouterParam(event, "email");
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Email parameter is required"
    });
  }
  const res = await query("SELECT id FROM orders WHERE email = ?", [email]);
  if (res.rows.length === 0) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not Found",
      message: "No orders found for this customer"
    });
  }
  await query("DELETE FROM orders WHERE email = ?", [email]);
  setResponseStatus(event, 204);
  return null;
});

export { _email__delete as default };
//# sourceMappingURL=_email_.delete.mjs.map
