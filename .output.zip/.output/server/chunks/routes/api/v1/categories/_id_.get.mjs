import { c as defineEventHandler, f as getRouterParam, e as createError } from '../../../../_/nitro.mjs';
import { q as query } from '../../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const _id__get = defineEventHandler(async (event) => {
  const idStr = getRouterParam(event, "id");
  const id = idStr ? parseInt(idStr, 10) : NaN;
  if (isNaN(id)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid category ID"
    });
  }
  const res = await query("SELECT * FROM categories WHERE id = ?", [id]);
  const category = res.rows[0];
  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not Found",
      message: "Category not found"
    });
  }
  return category;
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
