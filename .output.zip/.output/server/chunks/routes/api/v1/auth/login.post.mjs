import { c as defineEventHandler, r as readBody, e as createError } from '../../../../_/nitro.mjs';
import { q as query } from '../../../../_/db.mjs';
import { v as verifyPassword, c as createAccessToken } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email, password } = body || {};
  if (!email || !password) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Email and password are required"
    });
  }
  const res = await query("SELECT * FROM users WHERE email = ?", [email]);
  const user = res.rows[0];
  if (!user || !verifyPassword(password, user.hashed_password)) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized",
      message: "Incorrect email or password"
    });
  }
  const token = createAccessToken({ sub: user.email });
  return {
    access_token: token,
    token_type: "bearer"
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
