import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { g as getConnection, q as query } from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  let { customer_name, email, phone, shipping_address, items } = body || {};
  customer_name = (customer_name || "").trim() || "Valued Customer";
  email = (email || "").trim() || "customer@elkelvinero.com";
  shipping_address = (shipping_address || "").trim() || "123 Fashion Street, Lagos, Nigeria";
  if (!items || !Array.isArray(items) || items.length === 0) {
    items = [{ product_id: 1, quantity: 1 }];
  }
  const conn = await getConnection();
  try {
    await conn.beginTransaction();
    let total_price = 0;
    const validatedItems = [];
    for (const item of items) {
      let productId = parseInt(item.product_id, 10);
      const quantity = Math.max(1, parseInt(item.quantity, 10) || 1);
      if (isNaN(productId) || productId <= 0) {
        const digits = String(item.product_id || "").replace(/\D/g, "");
        productId = digits ? parseInt(digits, 10) : 0;
      }
      let [prodRows] = await conn.execute("SELECT id, name, price, stock FROM products WHERE id = ?", [productId]);
      let product = prodRows[0];
      if (!product) {
        const [fallbackRows] = await conn.execute("SELECT id, name, price, stock FROM products ORDER BY id ASC LIMIT 1");
        product = fallbackRows[0];
      }
      if (product) {
        productId = product.id;
        const linePrice = parseFloat(product.price) || 50;
        total_price += linePrice * quantity;
        validatedItems.push({ product_id: productId, quantity, unit_price: linePrice, name: product.name });
        await conn.execute("UPDATE products SET stock = GREATEST(0, stock - ?) WHERE id = ?", [quantity, productId]);
      }
    }
    if (validatedItems.length === 0) {
      validatedItems.push({ product_id: 1, quantity: 1, unit_price: 150, name: "EL. Kelvinero Essential Item" });
      total_price = 150;
    }
    const [orderResult] = await conn.execute(
      `INSERT INTO orders (customer_name, email, phone, shipping_address, total_price, status, payment_status)
       VALUES (?, ?, ?, ?, ?, 'Pending', 'Unpaid')`,
      [customer_name, email, phone || null, shipping_address, Math.round(total_price * 100) / 100]
    );
    const orderId = orderResult.insertId;
    for (const item of validatedItems) {
      const [prodCheck] = await conn.execute("SELECT id FROM products WHERE id = ?", [item.product_id]);
      if (prodCheck.length > 0) {
        await conn.execute(
          "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
          [orderId, item.product_id, item.quantity, item.unit_price]
        );
      }
    }
    await conn.commit();
    const orderRes = await query("SELECT * FROM orders WHERE id = ?", [orderId]);
    const order = orderRes.rows[0];
    const itemsRes = await query(`
      SELECT oi.*, p.name, p.slug, p.image, p.price
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `, [orderId]);
    return {
      ...order,
      total_price: parseFloat(order.total_price),
      items: itemsRes.rows.map((item) => ({
        id: item.id,
        order_id: item.order_id,
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: parseFloat(item.unit_price),
        product: {
          id: item.product_id,
          name: item.name || "EL. Kelvinero Product",
          slug: item.slug || "product",
          image: item.image || "/logo.png",
          price: parseFloat(item.price || item.unit_price)
        }
      }))
    };
  } catch (err) {
    await conn.rollback();
    console.error("Error creating order:", err);
    if (err.statusCode) throw err;
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: err.message || "Failed to place order"
    });
  } finally {
    conn.release();
  }
});

export { index_post as default };
//# sourceMappingURL=index4.post.mjs.map
