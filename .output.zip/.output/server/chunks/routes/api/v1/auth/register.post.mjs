import { c as defineEventHandler, r as readBody, e as createError } from '../../../../_/nitro.mjs';
import { q as query, g as getConnection } from '../../../../_/db.mjs';
import { h as hashPassword } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import 'bcryptjs';
import 'jsonwebtoken';

const register_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { name, email, password } = body || {};
  if (!name || !email || !password) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Name, email, and password are required"
    });
  }
  const existingRes = await query("SELECT id FROM users WHERE email = ?", [email]);
  if (existingRes.rows.length > 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Email is already registered"
    });
  }
  const countRes = await query("SELECT COUNT(*) as count FROM users");
  const userCount = parseInt(countRes.rows[0].count, 10);
  const isFirstUser = userCount === 0;
  const hashedPassword = hashPassword(password);
  const conn = await getConnection();
  try {
    const [result] = await conn.execute(
      "INSERT INTO users (name, email, hashed_password, is_admin) VALUES (?, ?, ?, ?)",
      [name, email, hashedPassword, isFirstUser ? 1 : 0]
    );
    const newId = result.insertId;
    const newUserRes = await query(
      "SELECT id, name, email, is_admin, created_at FROM users WHERE id = ?",
      [newId]
    );
    const newUser = newUserRes.rows[0];
    return {
      ...newUser,
      is_admin: Boolean(newUser.is_admin)
    };
  } finally {
    conn.release();
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
